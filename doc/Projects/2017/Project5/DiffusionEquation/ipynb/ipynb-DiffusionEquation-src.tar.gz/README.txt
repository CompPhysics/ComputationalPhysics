This IPython notebook DiffusionEquation.ipynb does not require any additional
programs.
