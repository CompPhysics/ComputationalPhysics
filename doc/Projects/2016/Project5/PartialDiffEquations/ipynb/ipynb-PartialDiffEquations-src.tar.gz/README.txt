This IPython notebook PartialDiffEquations.ipynb does not require any additional
programs.
