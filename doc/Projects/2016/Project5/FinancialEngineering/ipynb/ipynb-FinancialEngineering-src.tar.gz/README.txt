This IPython notebook FinancialEngineering.ipynb does not require any additional
programs.
