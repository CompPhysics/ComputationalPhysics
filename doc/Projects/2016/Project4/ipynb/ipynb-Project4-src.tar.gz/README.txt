This IPython notebook Project4.ipynb does not require any additional
programs.
