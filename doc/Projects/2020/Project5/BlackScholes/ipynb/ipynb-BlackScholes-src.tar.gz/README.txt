This IPython notebook BlackScholes.ipynb does not require any additional
programs.
