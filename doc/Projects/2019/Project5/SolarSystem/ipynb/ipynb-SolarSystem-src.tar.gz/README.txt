This IPython notebook SolarSystem.ipynb does not require any additional
programs.
