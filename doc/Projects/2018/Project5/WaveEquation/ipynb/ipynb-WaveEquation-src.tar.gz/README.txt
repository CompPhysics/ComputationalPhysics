This IPython notebook WaveEquation.ipynb does not require any additional
programs.
