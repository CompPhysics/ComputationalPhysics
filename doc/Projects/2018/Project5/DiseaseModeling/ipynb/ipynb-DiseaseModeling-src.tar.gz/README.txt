This IPython notebook DiseaseModeling.ipynb does not require any additional
programs.
