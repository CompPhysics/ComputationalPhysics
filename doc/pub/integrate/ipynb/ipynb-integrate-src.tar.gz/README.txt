This IPython notebook integrate.ipynb does not require any additional
programs.
