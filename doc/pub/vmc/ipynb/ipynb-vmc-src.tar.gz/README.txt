This IPython notebook vmc.ipynb does not require any additional
programs.
