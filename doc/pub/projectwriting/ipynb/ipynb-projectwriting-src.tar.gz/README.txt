This IPython notebook projectwriting.ipynb does not require any additional
programs.
