This IPython notebook rw.ipynb does not require any additional
programs.
