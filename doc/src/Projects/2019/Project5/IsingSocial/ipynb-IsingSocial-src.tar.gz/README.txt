This IPython notebook IsingSocial.ipynb does not require any additional
programs.
